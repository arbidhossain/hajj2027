VERSATILE HAJJ 2027 — Standalone dashboard (Netlify)
====================================================

WHAT THIS IS
  A single-file copy of your Hajj 2027 dashboard with all 219 pilgrims and
  your settings already loaded. It runs entirely in the browser and saves
  your changes to that browser's local storage.

  IMPORTANT: this standalone copy is per-device. Data is NOT shared live
  between staff or between computers/phones. Each browser keeps its own copy.
  Use Settings > Backup & restore to export a .json backup and import it on
  another device.

DEPLOY TO NETLIFY (drag & drop, no account command line)
  1. Go to https://app.netlify.com/drop
  2. Drag this whole folder (the one containing index.html) onto the page.
  3. Netlify gives you a live URL in a few seconds. Done.
  (To keep the same URL on future updates, create a site and use "Deploy
   manually" > drag the folder again, or connect it to a Git repo.)

OPEN LOCALLY
  Just double-click index.html — it works offline too.

WHAT'S NEW (27 Sep 2026)
  - Rooms: hotels in Makkah, Madina and Shisha/Aziziyah (Premium, Standard,
    Executive), room-by-room allocation, "keep together" for couples and
    families, auto-allocate, copy room-mates between cities, rooming list CSV.
  - Itineraries: day-by-day plan from flight dates, Hajj days from the
    Umm al-Qura calendar, copy for WhatsApp, CSV.
  - Calendar: Hajj days, flights, hotel dates, follow-ups, your own events.

UPDATING AN EXISTING SITE
  Uploading this version keeps the data already saved in each browser.
  Only a brand-new browser starts from the data shipped inside the file.

FILES
  index.html   the whole app + data (open or deploy this)
  README.txt   this file

BACKUP
  Settings tab > "Export full backup (.json)". Keep a recent backup safe.
  To restore or move to another PC: Settings > Import backup.
